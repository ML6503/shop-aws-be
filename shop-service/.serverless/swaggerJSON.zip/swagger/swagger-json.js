"use strict";
var __getOwnPropNames = Object.getOwnPropertyNames;
var __commonJS = (cb, mod) => function __require() {
  return mod || (0, cb[__getOwnPropNames(cb)[0]])((mod = { exports: {} }).exports, mod), mod.exports;
};

// swagger/swagger.js
var require_swagger = __commonJS({
  "swagger/swagger.js"(exports2, module2) {
    module2.exports = {
      "swagger": "2.0",
      "info": {
        "title": "shop-service",
        "version": "1"
      },
      "paths": {
        "/products": {
          "get": {
            "summary": "getProductsList",
            "description": "",
            "operationId": "getProductsList.get.products",
            "consumes": [
              "application/json"
            ],
            "produces": [
              "application/json"
            ],
            "parameters": [],
            "responses": {
              "200": {
                "description": "all products received successfully",
                "schema": {
                  "$ref": "#/definitions/function"
                }
              },
              "400": {
                "description": "Bad request. Product not found"
              }
            }
          },
          "post": {
            "summary": "addProduct",
            "description": "",
            "operationId": "addProduct.post.products",
            "consumes": [
              "application/json"
            ],
            "produces": [
              "application/json"
            ],
            "parameters": [],
            "responses": {
              "200": {
                "description": "Product created successfully",
                "schema": {
                  "$ref": '#/definitions/{"type":"object","properties":{"id":{"type":"string"},"title":{"type":"string"},"description":{"type":"string"},"price":{"type":"number"},"count":{"type":"number"}}}'
                }
              },
              "400": {
                "description": "Bad request."
              }
            }
          }
        },
        "/products/{productId}": {
          "get": {
            "summary": "getProductsById",
            "description": "",
            "operationId": "getProductsById.get.products/{productId}",
            "consumes": [
              "application/json"
            ],
            "produces": [
              "application/json"
            ],
            "parameters": [
              {
                "name": "productId",
                "in": "path",
                "required": true,
                "type": "string"
              }
            ],
            "responses": {
              "200": {
                "description": "Product received successfully",
                "schema": {
                  "$ref": "#/definitions/IProduct"
                }
              },
              "400": {
                "description": "Bad request. Product not found"
              },
              "404": {
                "description": "Product not found"
              }
            }
          }
        }
      },
      "definitions": {
        "IProduct": {
          "properties": {
            "id": {
              "title": "IProduct.id",
              "type": "string"
            },
            "title": {
              "title": "IProduct.title",
              "type": "string"
            },
            "description": {
              "title": "IProduct.description",
              "type": "string"
            },
            "price": {
              "title": "IProduct.price",
              "type": "number"
            }
          },
          "required": [
            "id",
            "title",
            "description",
            "price"
          ],
          "additionalProperties": false,
          "title": "IProduct",
          "type": "object"
        },
        "IProductWzStock": {
          "properties": {
            "count": {
              "title": "IProductWzStock.count",
              "type": "number"
            }
          },
          "required": [
            "count"
          ],
          "additionalProperties": false,
          "title": "IProductWzStock",
          "type": "object"
        },
        "INewProduct": {
          "properties": {
            "title": {
              "title": "INewProduct.title",
              "type": "string"
            },
            "description": {
              "title": "INewProduct.description",
              "type": "string"
            },
            "price": {
              "title": "INewProduct.price",
              "type": "number"
            },
            "count": {
              "title": "INewProduct.count",
              "type": "number"
            }
          },
          "required": [
            "title",
            "description",
            "price",
            "count"
          ],
          "additionalProperties": false,
          "title": "INewProduct",
          "type": "object"
        },
        "IProducts": {
          "properties": {
            "products": {
              "items": {
                "$ref": "#/definitions/IProduct",
                "title": "IProducts.products.[]"
              },
              "title": "IProducts.products",
              "type": "array"
            }
          },
          "required": [
            "products"
          ],
          "additionalProperties": false,
          "title": "IProducts",
          "type": "object"
        }
      },
      "securityDefinitions": {}
    };
  }
});

// swagger/swagger-json.js
var swagger = require_swagger();
exports.handler = async () => {
  return {
    statusCode: 200,
    body: JSON.stringify(swagger)
  };
};
//# sourceMappingURL=swagger-json.js.map
